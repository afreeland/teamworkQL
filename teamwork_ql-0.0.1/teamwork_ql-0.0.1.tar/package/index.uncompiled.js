// var schema = require('./build/data/schema');
// module.exports = schema;
import schema from './build/data/schema';


export default schema;