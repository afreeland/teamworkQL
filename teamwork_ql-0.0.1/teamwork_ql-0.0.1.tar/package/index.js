'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _schema = require('./build/data/schema');

var _schema2 = _interopRequireDefault(_schema);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _schema2.default; // var schema = require('./build/data/schema');
// module.exports = schema;
