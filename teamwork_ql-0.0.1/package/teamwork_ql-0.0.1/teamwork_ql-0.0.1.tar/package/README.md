# teamworkQL
Simple wrapper to help with communication to Teamwork API
