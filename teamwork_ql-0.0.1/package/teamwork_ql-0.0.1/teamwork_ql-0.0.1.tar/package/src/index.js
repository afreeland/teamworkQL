import schema from './data/schema';




export default schema;